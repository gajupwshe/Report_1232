<?php



$valve_serial_no = $_GET['valve_serial_no'];
session_start();
$conn = new mysqli('localhost', $_SESSION['db_user'], $_SESSION['db_pass'], $_SESSION['db_name']) or trigger_error(mysqli_error(),E_USER_ERROR);

?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="img/author.png">
    <title> Reports | Customised Activity Reports</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- bootstrap 3.0.2 -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <!-- font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <!-- Ionicons -->
    <link href="css/ionicons.min.css" rel="stylesheet" type="text/css"/>
    <!-- DATA TABLES -->
    <link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css"/>
    <!-- Theme style -->
    <link href="css/AdminLTE.css" rel="stylesheet" type="text/css"/>

    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- bootstrap 3.0.2 -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <!-- font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <!-- Ionicons -->
    <link href="css/ionicons.min.css" rel="stylesheet" type="text/css"/>
    <!-- Morris chart -->
    <link href="css/morris/morris.css" rel="stylesheet" type="text/css"/>
    <!-- jvectormap -->
    <link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css"/>
    <!-- fullCalendar -->
    <link href="css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css"/>
    <!-- Daterange picker -->
    <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css"/>
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css"/>
    <!-- Theme style -->

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>

    <![endif]-->
    <link rel="stylesheet" href="pikaday.css">
    <!--    <link rel="stylesheet" href="site.css">-->


</head>
<body class="skin-black">
<!-- header logo: style can be found in header.less -->


<div class="wrapper row-offcanvas row-offcanvas-left">
    <!-- Left side column. contains the logo and sidebar -->

    <?php include('nav_left.php');?>

    <!-- /.sidebar -->

    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->


        <!-- Main content -->
        <section class="content">

            <!-- Small boxes (Stat box) -->
            <div class="row" style="/*border: 1px solid #000000; border-radius: 10px;*/">

                <h1 style="text-align: center"><i class="fa fa-calendar"></i> Valve Test Reports</h1>
            </div>
            <!-- /.row -->

            <!-- top row -->
            <div class="row">
                <div class="col-xs-12 connectedSortable">
                    <div class="col-lg-12 connectedSortable" style="padding: 20px;" >


                        <form action="#" method="post">
                            <div style="">
                                <?php

//                                $_SESSION['test_no']=$test_no;
                                $_SESSION['valve_serial_no']=$valve_serial_no;

                                $sql = "SELECT DISTINCT(vd.`valve_serial_no`),vd.`valve_tag_no`,vd.`imir_no`,vd.`manufacturer`,vd.`customer`,vd.`operator`,vd.`shift`,vd.`project`,tr.`gauge_serial_no`,tr.`guage_calibration_date`,tr.`valve_type`,vd.`date_time`,tr.`valve_size`,tr.`valve_class` FROM `test_result` tr  JOIN `valve_data` vd ON (tr.`test_no` = vd.`test_no` AND tr.`test_type` = vd.`test_type`) WHERE  tr.`valve_serial_no` = '$valve_serial_no'";

                                $result = $conn->query($sql);
                                if ($result->num_rows > 0){
                                if($row = $result->fetch_assoc()){
                                ?>
                                <center>
                                    <div class="" style="text-align: center; margin-left: 25%">
                                        <table >
                                            <tr style="padding: 10px; font-size: 20px; text-align: center">
                                                <td style="border: 1px solid #000; width: 200px;"><b> VALVE SERIAL NO. </b> </td>
                                                <td style="border: 1px solid #000; width: 200px;"><?php echo $row['valve_serial_no'];?></td>
                                                <td style="border: 1px solid #000; width: 200px;"><b>CUSTOMER</b> </td>
                                                <td style="border: 1px solid #000; width: 200px;"><?php echo $row['customer']; ?>  </td>
                                            </tr>
                                            <tr style="padding: 10px; font-size: 20px; text-align: center">
                                                <td style="border: 1px solid #000; width: 200px;"><b> VALVE TAG NO. </b> </td>
                                                <td style="border: 1px solid #000; width: 200px;"><?php echo $row['valve_tag_no'];?></td>
                                                <td style="border: 1px solid #000; width: 200px;"><b>  MANUFACTURER </b> </td>
                                                <td style="border: 1px solid #000; width: 200px;"><?php echo $row['manufacturer'];?></td>
                                            </tr>
                                            <tr style="padding: 10px; font-size: 20px; text-align: center">
                                                <td style="border: 1px solid #000;width: 200px;"><b>IMIR NO.</b> </td>
                                                <td style="border: 1px solid #000;width: 200px;"><?php echo $row['imir_no'];?></td>
                                                <td style="border: 1px solid #000;width: 200px;"><b>VALVE SIZE</b> </td>
                                                <td style="border: 1px solid #000;width: 200px;"><?php echo $row['valve_size'];?></td>
                                            </tr>
                                            <tr style="padding: 10px; font-size: 20px; text-align: center">
                                                <td style="border: 1px solid #000;width: 200px;"><b>VALVE CLASS</b> </td>
                                                <td style="border: 1px solid #000;width: 200px;"><?php echo $row['valve_class'];?></td>
                                                <td style="border: 1px solid #000; width: 200px;"><b>PROJECT</b> </td>
                                                <td style="border: 1px solid #000; width: 200px;"><?php echo $row['project'];?></td>
                                            </tr>
                                            <tr style="padding: 10px; font-size: 20px; text-align: center">
                                                <td style="border: 1px solid #000; width: 200px;"><b>VALVE TYPE</b> </td>
                                                <td style="border: 1px solid #000; width: 200px;"><?php echo $row['valve_type'];}}?></td>
                                                <td style="border: 1px solid #000; cursor: pointer; width: 200px; background: #9e9e9e; color: #000" onclick="myFunction()"><b>Export EXCEL</b></td>
                                                <td style="border: 1px solid #000; width: 200px; background: #9e9e9e;"><b><a href="vtr_pdf.php" style="color: #000" >Export PDF</a></b></td>
                                                <!--                                    <td style="border: 1px solid #000; width: 200px; background: #9e9e9e;"><b><a href="excel.php" style="color: #000" >Export PDF</a></b></td>-->
                                            </tr>
                                        </table>

                                        <h1 style="text-align: left;">

                                        </h1>
                                    </div>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
            <script>
                function myFunction() {
                    alert("<?php echo $sql;?>");
                }
            </script>
            <!-- Main row -->





<br/>
<br/>


            <?php
            $shell_test_no = '45';
                $sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='HYDROSTATIC SHELL'  ORDER BY `test_no` DESC LIMIT 1";

            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            if($row = $result->fetch_assoc()) {
                $shell_test_no = $row['test_no'];
            }}
            $sql_shell = "SELECT tr.*,vr.* FROM `test_result` tr JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$shell_test_no'";
            $result_shell = $conn->query($sql_shell);
            if ($result_shell->num_rows > 0) {
                ?>

            <div class="row" >
                <!-- Left col -->
                <section class="col-lg-12 connectedSortable" >
                    <!-- Box (with bar chart) -->
                    <div class="box box-danger" id="loading-example">
                        <div class="box-header"  >
                            <!-- tools box -->

<?php
                                if($row = $result_shell->fetch_assoc()){
                                    ?>
                                    <h3 style="margin-left: 25%;">
                                        HYDROSTATIC SHELL TEST
                                    </h3>

                                    <table >
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>TEST DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['date_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>WATER TEMPERATURE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['water_temperature'];?>&deg;C</td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OPERATOR NAME </b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['operator'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>SHIFT</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['shift'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px; text-align: start;"><b>PRESSURE GAUGE NO. </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['gauge_serial_no'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>CALIBRATION DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['guage_calibration_date'];?></td>
                                        </tr>
					<?php 
						if($row['leakage_type'] == "NONE"){
						}else{
					?>
					<tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>LEAKAGE TYPE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['leakage_type'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>ACTUAL LEAKAGE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['actual_leakage'];?></td>
                                        </tr>
					<?php }?>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT START (<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_a'];?></td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT END (<?php echo $row['pressure_unit'];?>)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['stop_pressure_a'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>SET PRESSURE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['hydro_set_pressure'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>HOLDING TIME ACTUAL (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['holding_time'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">

                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OVERALL TEST TIME (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['over_all_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>RESULT</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php if($row['test_result'] == '2'){echo "TEST NOT OK";}else{echo "TEST OK";}?></td>
                                        </tr>
                                    </table>




                        </div>
                    </div>
                    <!-- /.box -->

                    <!-- Custom tabs (Charts with tabs)-->


                </section>
                <!-- /.Left col -->

            </div>
            <!-- /.row (main row) -->


            <?php }}else{}?>
            <br/>
            <br/>



            <?php
            $sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='HYDROSTATIC SEAT A SIDE'  ORDER BY `test_no` DESC LIMIT 1";
            $seat_a_test_no = '45';
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                if($row = $result->fetch_assoc()) {
                    $seat_a_test_no = $row['test_no'];
                }
            }
            $sql_seat_a = "SELECT tr.*,vr.* FROM `test_result` tr JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$seat_a_test_no'";
            $result_seat_a = $conn->query($sql_seat_a);
            if ($result_seat_a->num_rows > 0) {?>

            <div class="row">
                <!-- Left col -->
                <section class="col-lg-12 connectedSortable">
                    <!-- Box (with bar chart) -->
                    <div class="box box-danger" id="loading-example">
                        <div class="box-header">
                            <!-- tools box -->


                           <?php
                                if($row = $result_seat_a->fetch_assoc()){
                                    ?>
                                    <h1 style="margin-left: 25%;">
                                        HYDROSTATIC SEAT TEST SIDE - A
                                    </h1>

                                    <table>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>TEST DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['date_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>WATER TEMPERATURE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['water_temperature'];?>&deg;C</td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OPERATOR NAME </b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['operator'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>SHIFT</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['shift'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>PRESSURE GAUGE NO. </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['gauge_serial_no'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>CALIBRATION DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['guage_calibration_date'];?></td>
                                        </tr>
					<?php 
						if($row['leakage_type'] == "NONE"){
						}else{
					?>
					<tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>LEAKAGE TYPE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['leakage_type'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>ACTUAL LEAKAGE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['actual_leakage'];?></td>
                                        </tr>
					<?php }?>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT START (<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_a'];?></td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT END (<?php echo $row['pressure_unit'];?>)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['stop_pressure_a'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>SET PRESSURE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['hydro_set_pressure'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>HOLDING TIME ACTUAL (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['holding_time'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OVERALL TEST TIME (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['over_all_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>RESULT</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php if($row['test_result'] == '2'){echo "TEST NOT OK";}else{echo "TEST OK";}?></td>
                                        </tr>
                                    </table>




                        </div>
                    </div>
                    <!-- /.box -->

                    <!-- Custom tabs (Charts with tabs)-->


                </section>
                <!-- /.Left col -->

            </div>


            <?php }}else{}?>

            <br/>
            <br/>
            <?php
            $sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='HYDROSTATIC SEAT B SIDE'  ORDER BY `test_no` DESC LIMIT 1";
            $seat_b_test_no = '45';
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                if($row = $result->fetch_assoc()) {
                    $seat_b_test_no = $row['test_no'];
                }
            }
            $sql_seat_b = "SELECT tr.*,vr.* FROM `test_result` tr JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$seat_b_test_no'";
            $result_seat_b = $conn->query($sql_seat_b);
            if ($result_seat_b->num_rows > 0) {?>

            <div class="row">
                <!-- Left col -->
                <section class="col-lg-12 connectedSortable">
                    <!-- Box (with bar chart) -->
                    <div class="box box-danger" id="loading-example">
                        <div class="box-header">
                            <!-- tools box -->


                          <?php
                                if($row = $result_seat_b->fetch_assoc()){
                                    ?>
                                    <h1 style="margin-left: 25%;">
                                        HYDROSTATIC SEAT TEST SIDE - B
                                    </h1>

                                    <table>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>TEST DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['date_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>WATER TEMPERATURE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['water_temperature'];?>&deg;C</td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OPERATOR NAME </b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['operator'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>SHIFT</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['shift'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>PRESSURE GAUGE NO. </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['gauge_serial_no'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>CALIBRATION DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['guage_calibration_date'];?></td>
                                        </tr>
					<?php 
						if($row['leakage_type'] == "NONE"){
						}else{
					?>
					<tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>LEAKAGE TYPE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['leakage_type'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>ACTUAL LEAKAGE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['actual_leakage'];?></td>
                                        </tr>
					<?php }?>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT START (<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_b'];?></td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT END (<?php echo $row['pressure_unit'];?>)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['stop_pressure_b'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>SET PRESSURE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['hydro_set_pressure'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>HOLDING TIME ACTUAL (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['holding_time'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OVERALL TEST TIME (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['over_all_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>RESULT</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php if($row['test_result'] == '2'){echo "TEST NOT OK";}else{echo "TEST OK";}?></td>
                                        </tr>
                                    </table>




                        </div>
                    </div>
                    <!-- /.box -->

                    <!-- Custom tabs (Charts with tabs)-->


                </section>
                <!-- /.Left col -->

            </div>

            <?php }}else{}?>

            <br/>
            <br/>
            <?php
            $sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='PNEUMATIC SEAT A SIDE'  ORDER BY `test_no` DESC LIMIT 1";
            $air_a_test_no = '45';
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                if($row = $result->fetch_assoc()) {
                    $air_a_test_no = $row['test_no'];
                }
            }
            $sql_air_a = "SELECT tr.*,vr.* FROM `test_result` tr JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$air_a_test_no'";
            $result_air_a = $conn->query($sql_air_a);
            if ($result_air_a->num_rows > 0) {?>

            <div class="row">
                <!-- Left col -->
                <section class="col-lg-12 connectedSortable">
                    <!-- Box (with bar chart) -->
                    <div class="box box-danger" id="loading-example">
                        <div class="box-header">
                            <!-- tools box -->


                           <?php
                                if($row = $result_air_a->fetch_assoc()){
                                    ?>
                                    <h1 style="margin-left: 25%;">
                                        PNEUMATIC TEST SIDE- A
                                    </h1>

                                    <table>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>TEST DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['date_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>WATER TEMPERATURE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['water_temperature'];?>&deg;C</td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OPERATOR NAME </b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['operator'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>SHIFT</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['shift'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>PRESSURE GAUGE NO. </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['gauge_serial_no'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>CALIBRATION DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['guage_calibration_date'];?></td>
                                        </tr>
					<?php 
						if($row['leakage_type'] == "NONE"){
						}else{
					?>
					<tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>LEAKAGE TYPE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['leakage_type'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>ACTUAL LEAKAGE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['actual_leakage'];?></td>
                                        </tr>
					<?php }?>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT START (<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_a'];?></td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT END (<?php echo $row['pressure_unit'];?>)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['stop_pressure_a'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>SET PRESSURE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['hydro_set_pressure'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>HOLDING TIME ACTUAL (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['holding_time'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OVERALL TEST TIME (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['over_all_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>RESULT</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php if($row['test_result'] == '2'){echo "TEST NOT OK";}else{echo "TEST OK";}?></td>

                                        </tr>
                                    </table>




                        </div>
                    </div>
                    <!-- /.box -->

                    <!-- Custom tabs (Charts with tabs)-->


                </section>
                <!-- /.Left col -->

            </div>

            <?php }}else{}?>


            <br/>
            <br/>
            <?php
            $sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='PNEUMATIC SEAT B SIDE'  ORDER BY `test_no` DESC LIMIT 1";
            $air_b_test_no = '45';
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                if($row = $result->fetch_assoc()) {
                    $air_b_test_no = $row['test_no'];
                }
            }
            $sql_air_b = "SELECT tr.*,vr.* FROM `test_result` tr JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$air_b_test_no'";
            $result_air_b = $conn->query($sql_air_b);
            if ($result_air_b->num_rows > 0) {?>
            <div class="row">
                <!-- Left col -->
                <section class="col-lg-12 connectedSortable">
                    <!-- Box (with bar chart) -->
                    <div class="box box-danger" id="loading-example">
                        <div class="box-header">
                            <!-- tools box -->


                           <?php
                                if($row = $result_air_b->fetch_assoc()){
                                    ?>
                                    <h1 style="margin-left: 25%;">
                                        PNEUMATIC TEST SIDE- B
                                    </h1>

                                    <table>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>TEST DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['date_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>WATER TEMPERATURE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['water_temperature'];?>&deg;C</td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OPERATOR NAME </b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['operator'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>SHIFT</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['shift'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>PRESSURE GAUGE NO. </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['gauge_serial_no'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>CALIBRATION DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['guage_calibration_date'];?></td>
                                        </tr>
					<?php 
						if($row['leakage_type'] == "NONE"){
						}else{
					?>
					<tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>LEAKAGE TYPE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['leakage_type'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>ACTUAL LEAKAGE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['actual_leakage'];?></td>
                                        </tr>
					<?php }?>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT START (<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_b'];?></td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT END (<?php echo $row['pressure_unit'];?>)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['stop_pressure_b'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>SET PRESSURE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['hydro_set_pressure'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>HOLDING TIME ACTUAL (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['holding_time'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OVERALL TEST TIME (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['over_all_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>RESULT</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php if($row['test_result'] == '2'){echo "TEST NOT OK";}else{echo "TEST OK";}?></td>
                                        </tr>
                                    </table>



                        </div>
                    </div>
                    <!-- /.box -->

                    <!-- Custom tabs (Charts with tabs)-->


                </section>
                <!-- /.Left col -->

            </div>


            <?php }}else{}?>


            <br/>
            <br/>
            <?php
            $sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='DOUBLE BLOCK BLEED TEST'  ORDER BY `test_no` DESC LIMIT 1";
            $double_test_no = '45';
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                if($row = $result->fetch_assoc()) {
                    $double_test_no = $row['test_no'];
                }
            }
            $sql_double = "SELECT tr.*,vr.* FROM `test_result` tr JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$double_test_no'";
            $result_double = $conn->query($sql_double);
            if ($result_double->num_rows > 0) {?>




            <div class="row">
                <!-- Left col -->
                <section class="col-lg-12 connectedSortable">
                    <!-- Box (with bar chart) -->
                    <div class="box box-danger" id="loading-example">
                        <div class="box-header">
                            <!-- tools box -->


                           <?php
                                if($row = $result_double->fetch_assoc()){
                                    ?>
                                    <h1 style="margin-left: 25%;">
                                        DOUBLE BLOCK BLEED TEST
                                    </h1>

                                    <table>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>TEST DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['date_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>WATER TEMPERATURE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['water_temperature'];?>&deg;C</td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OPERATOR NAME </b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['operator'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>SHIFT</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['shift'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>PRESSURE GAUGE NO. </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['gauge_serial_no'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>CALIBRATION DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['guage_calibration_date'];?></td>
                                        </tr>
					<?php 
						if($row['leakage_type'] == "NONE"){
						}else{
					?>
					<tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>LEAKAGE TYPE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['leakage_type'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>ACTUAL LEAKAGE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['actual_leakage'];?></td>
                                        </tr>
					<?php }?>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT START A SIDE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_a'];?></td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT END A SIDE(<?php echo $row['pressure_unit'];?>)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['stop_pressure_a'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT START B SIDE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_b'];?></td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT END B SIDE(<?php echo $row['pressure_unit'];?>)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['stop_pressure_b'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>SET PRESSURE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['hydro_set_pressure'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>HOLDING TIME ACTUAL (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['holding_time'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OVERALL TEST TIME (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['over_all_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>RESULT</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php if($row['test_result'] == '2'){echo "TEST NOT OK";}else{echo "TEST OK";}?></td>
                                        </tr>
                                    </table>

                        </div>
                    </div>
                    <!-- /.box -->

                    <!-- Custom tabs (Charts with tabs)-->


                </section>
                <!-- /.Left col -->

            </div>



            <?php }}else{}?>





            <br/>
            <br/>
            <?php
            $sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='BACK SEAT TEST'  ORDER BY `test_no` DESC LIMIT 1";
            $back_seat_test_no = '45';
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                if($row = $result->fetch_assoc()) {
                    $back_seat_test_no = $row['test_no'];
                }
            }
            $sql_back_seat = "SELECT tr.*,vr.* FROM `test_result` tr JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$back_seat_test_no'";
            $result_back_seat = $conn->query($sql_back_seat);
            if ($result_back_seat->num_rows > 0) {?>

            <div class="row">
                <!-- Left col -->
                <section class="col-lg-12 connectedSortable">
                    <!-- Box (with bar chart) -->
                    <div class="box box-danger" id="loading-example">
                        <div class="box-header">
                            <!-- tools box -->


                                <?php
                                if($row = $result_back_seat->fetch_assoc()){
                                    ?>
                                    <h1 style="margin-left: 25%;">
                                        BACK SEAT TEST
                                    </h1>

                                    <table>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>TEST DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['date_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>WATER TEMPERATURE</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['water_temperature'];?>&deg;C</td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OPERATOR NAME </b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['operator'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>SHIFT</b> </td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['shift'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>PRESSURE GAUGE NO. </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['gauge_serial_no'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>CALIBRATION DATE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['guage_calibration_date'];?></td>
                                        </tr>
					<?php 
						if($row['leakage_type'] == "NONE"){
						}else{
					?>
					<tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>LEAKAGE TYPE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['leakage_type'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>ACTUAL LEAKAGE</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['actual_leakage'];?></td>
                                        </tr>
					<?php }?>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT START (<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_a'];?></td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>PRESSURE AT END (<?php echo $row['pressure_unit'];?>)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['stop_pressure_a'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>SET PRESSURE(<?php echo $row['pressure_unit'];?>) </b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['hydro_set_pressure'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>HOLDING TIME ACTUAL (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['holding_time'];?></td>
                                        </tr>
                                        <tr style="padding: 10px; font-size: 20px; text-align: center">
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OVERALL TEST TIME (SEC)</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['over_all_time'];?></td>
                                            <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>RESULT</b> </td>
                                            <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php if($row['test_result'] == '2'){echo "TEST NOT OK";}else{echo "TEST OK";}?></td>

                                        </tr>
                                    </table>




                        </div>
                    </div>
                    <!-- /.box -->

                    <!-- Custom tabs (Charts with tabs)-->


                </section>
                <!-- /.Left col -->

            </div>
            <?php }}else{}?>







            <br/>
            <br/>
            <?php
            $sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='CAVITY RELIEF TEST'  ORDER BY `test_no` DESC LIMIT 1";
            $cavity_relief_test = '45';
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                if($row = $result->fetch_assoc()) {
                    $cavity_relief_test = $row['test_no'];
                }
            }
            $sql_cavity_relief = "SELECT tr.*,vr.* FROM `test_result` tr JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$cavity_relief_test'";
            $result_back_seat = $conn->query($sql_cavity_relief);

            if ($result_back_seat->num_rows > 0) {?>

            <div class="row">
                <!-- Left col -->
                <section class="col-lg-12 connectedSortable">
                    <!-- Box (with bar chart) -->
                    <div class="box box-danger" id="loading-example">
                        <div class="box-header">
                            <!-- tools box -->


                            <?php
                            if($row = $result_back_seat->fetch_assoc()){
                            ?>
                            <h1 style="margin-left: 25%;">
                                Cavity Relief Test
                            </h1>

                            <table>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>TEST DATE</b> </td>
                                    <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['date_time'];?></td>
                                    <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>WATER TEMPERATURE</b> </td>
                                    <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['water_temperature'];?>&deg;C</td>
                                </tr>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>OPERATOR NAME </b> </td>
                                    <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['operator'];?></td>
                                    <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>SHIFT</b> </td>
                                    <td style="border: 1px solid #000; width: 200px;text-align: start; padding-left: 20px;"><?php echo $row['shift'];?></td>
                                </tr>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>PRESSURE GAUGE NO. </b> </td>
                                    <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['gauge_serial_no'];?></td>
                                    <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>CALIBRATION DATE</b> </td>
                                    <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['guage_calibration_date'];?></td>
                                </tr>
				<?php 
					if($row['leakage_type'] == "NONE"){
					}else{
				?>
				<tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>LEAKAGE TYPE</b> </td>
                                    <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['leakage_type'];?></td>
                                    <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>ACTUAL LEAKAGE</b> </td>
                                    <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['actual_leakage'];?></td>
                                </tr>
				<?php }?>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>CAVITY RELIEF PRESSURE (<?php echo $row['pressure_unit'];?>) </b> </td>
                                    <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['hydro_set_pressure'];?></td>
                                    <td style="border: 1px solid #000; width: 300px;text-align: start;"><b>ACTUAL CAVITY RELIEF PRESSURE (<?php echo $row['pressure_unit'];?>)</b> </td>
                                    <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php echo $row['start_pressure_a'];?></td>
                                </tr>

                                <tr style="padding: 10px; font-size: 20px; text-align: center">

                                    <td style="border: 1px solid #000; width: 200px;text-align: start;"><b>RESULT</b> </td>
                                    <td style="border: 1px solid #000; width: 300px;text-align: start; padding-left: 20px;"><?php if($row['test_result'] == '2'){echo "TEST NOT OK";}else{echo "TEST OK";}?></td>
                                </tr>
                            </table>




                        </div>
                    </div>
                    <!-- /.box -->

                    <!-- Custom tabs (Charts with tabs)-->


                </section>
                <!-- /.Left col -->

            </div>


                            <?php }}else{}?>


        </section>
        <!-- /.content -->
    </aside>
    <!-- /.right-side -->
</div>
<!-- ./wrapper -->

<!-- add new calendar event modal -->


<script src="pikaday.js"></script>
<script>

    new Pikaday(
        {
            field:document.getElementById('datepicker'),
            trigger:document.getElementById('datepicker-button'),
            minDate:new Date(2000, 0, 1),
            ariaLabel:'Custom label',
            maxDate:new Date(3020, 12, 31),
            yearRange:[2010, 2080]
        });

    new Pikaday(
        {
            field:document.getElementById('datepicker_end'),
            trigger:document.getElementById('datepicker_end-button'),
            minDate:new Date(2000, 0, 1),
            ariaLabel:'Custom label',
            maxDate:new Date(3020, 12, 31),
            yearRange:[2010, 2080]
        });

</script>
<script src="js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- Morris.js charts -->
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="js/plugins/morris/morris.min.js" type="text/javascript"></script>
<!-- Sparkline -->
<script src="js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
<!-- jvectormap -->
<script src="js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
<script src="js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
<!-- fullCalendar -->
<script src="js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
<!-- jQuery Knob Chart -->
<script src="js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
<!-- daterangepicker -->
<script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
<!-- iCheck -->
<script src="js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>

<!-- AdminLTE App -->
<script src="js/AdminLTE/app.js" type="text/javascript"></script>

<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="js/AdminLTE/dashboard.js" type="text/javascript"></script>

<!-- jQuery 2.0.2 -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- DATA TABES SCRIPT -->
<script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
<!-- AdminLTE App -->

<!-- page script -->
<script type="text/javascript">
    $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
            "bPaginate":true,
            "bLengthChange":false,
            "bFilter":false,
            "bSort":true,
            "bInfo":true,
            "bAutoWidth":false
        });
    });
</script>


</body>
</html>
