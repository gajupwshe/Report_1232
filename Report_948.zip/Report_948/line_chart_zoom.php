
<script>
var x = [];
var y = [];
var int_y = 1;
</script>
<?php
$test_no = $_GET['test_no'];
session_start();

$conn = new mysqli('localhost', $_SESSION['db_user'], $_SESSION['db_pass'], $_SESSION['db_name']) or trigger_error(mysqli_error(),E_USER_ERROR);


$query = "SELECT * FROM `test_result_by_type` WHERE  `test_no` = $test_no ";
$result = mysqli_query($conn, $query);
$chart_data = '';
$db_user = $_SESSION['db_user'];
$db_pass = $_SESSION['db_pass'];
$db_name = $_SESSION['db_name'];
while($row = mysqli_fetch_array($result)) {

?>
    <script>
        x.push(<?php echo $row['hydro_pressure_a_side']; ?>);

        y.push(int_y);
        int_y++;
        // alert(x+" and "+y);
    </script>
<?php

}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link href="./css/nv.d3.css" rel="stylesheet" type="text/css">
    <!-- bootstrap 3.0.2 -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- DATA TABLES -->
    <link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />

    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- bootstrap 3.0.2 -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="css/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- fullCalendar -->
    <link href="css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <!--[if lt IE 9]-->
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="./js/d3.min.js" charset="utf-8"></script>
    <script src="./js/nv.d3.js"></script>

    <style>
        text {
            font: 12px sans-serif;
        }
        svg {
            display: block;
        }
        html, body, #chart1, svg {
            margin: 0px;
            padding: 0px;
            height: 100%;
            width: 100%;
        }
        #chartZoom {
            position: relative;
            top: 0;
            left: 0;
        }
    </style>

</head>
<body class="skin-black">

<!--Side bar-->
<?php include('nav_left.php');?>

<aside class="right-side">
    <!-- Main content -->
    <section class="content">

        <div id="chartZoom" >
            <i id="zoomIn"><button class="btn btn-primary btn-xs "><img src="./img/zoom_in.png"></button></i>   <i id="zoomOut"><button class="btn btn-primary btn-xs"> <img src="./img/zoom_out.png"></button></i>
            <button class="btn btn-primary btn-xs fa fa-5x fa-save" onclick="alert_test()"></button>
            <div id="chart1" class='with-3d-shadow with-transitions'>
                <svg></svg>
            </div>
        </div>

<script>
    function alert_test() {
        alert('testing test no');
    }
</script>
    </section>

</aside>


<script>

    nv.addGraph(function() {
        var chart = nv.models.lineChart();
        var fitScreen = false;
        var width = 600;
        var height = 300;
        var zoom = 1;

        chart.useInteractiveGuideline(true);
        chart.xAxis
            .tickFormat(d3.format(',r'));

        chart.lines.dispatch.on("elementClick", function(evt) {
            console.log(evt);
        });

        chart.yAxis
            .axisLabel('')
            .tickFormat(d3.format(',.2f'));

        d3.select('#chart1 svg')
            .attr('perserveAspectRatio', 'xMinYMid')
            .attr('width', width)
            .attr('height', height)
            .datum(sinAndCos());

        setChartViewBox();
        resizeChart();

        nv.utils.windowResize(resizeChart);

        d3.select('#zoomIn').on('click', zoomIn);
        d3.select('#zoomOut').on('click', zoomOut);


        function setChartViewBox() {
            var w = width * zoom,
                h = height * zoom;

            chart
                .width(w)
                .height(h);

            d3.select('#chart1 svg')
                .attr('viewBox', '0 0 ' + w + ' ' + h)
                .transition().duration(500)
                .call(chart);
        }

        function zoomOut() {
            zoom += .25;
            setChartViewBox();
        }

        function zoomIn() {
            if (zoom <= .5) return;
            zoom -= .25;
            setChartViewBox();
        }

        // This resize simply sets the SVG's dimensions, without a need to recall the chart code
        // Resizing because of the viewbox and perserveAspectRatio settings
        // This scales the interior of the chart unlike the above
        function resizeChart() {
            var container = d3.select('#chart1');
            var svg = container.select('svg');

            if (fitScreen) {
                // resize based on container's width AND HEIGHT
                var windowSize = nv.utils.windowSize();
                svg.attr("width", windowSize.width);
                svg.attr("height", windowSize.height);
            } else {
                // resize based on container's width
                var aspect = chart.width() / chart.height();
                var targetWidth = parseInt(container.style('width'));
                svg.attr("width", targetWidth);
                svg.attr("height", Math.round(targetWidth / aspect));
            }
        }
        return chart;
    });

    function sinAndCos() {
        var sin = [],
            cos = [];

        for (var i = 0; i < 100; i++) {
            sin.push({x: y[i], y: x[i] });
            cos.push({x: x[i], y: .5 * Math.cos(i/10)});
        }

        return [
            {
                values: sin,
                key: "Hydro Test Pressure",
                color: "#0099FF"
            }
        ];
    }

</script>
</body>
</html>