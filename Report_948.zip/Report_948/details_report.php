<?php

session_start();

$test_no = $_GET['test_no'];
$test_type = $_GET['test_type'];
//include('db_config.php');
$conn = new mysqli('localhost', $_SESSION['db_user'], $_SESSION['db_pass'], $_SESSION['db_name']) or trigger_error(mysql_error(),E_USER_ERROR);
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="img/author.png">
    <title> Reports</title>


    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- bootstrap 3.0.2 -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- font Awesome -->
    <!--    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />-->
    <!-- Ionicons -->
    <!--    <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />-->
    <!-- DATA TABLES -->
    <link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <!--    <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />-->
    <!-- Morris chart -->
    <!--    <link href="css/morris/morris.css" rel="stylesheet" type="text/css" />-->
    <!-- jvectormap -->
    <!--    <link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />-->
    <!-- fullCalendar -->
    <!--    <link href="css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />-->
    <!-- Daterange picker -->
    <!--    <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />-->
    <!-- bootstrap wysihtml5 - text editor -->
    <!--    <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />-->
    <!-- Theme style -->

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <!--<script src="js/html5shiv.js"></script>-->
    <!--<script src="js/respond.min.js"></script>-->
    <![endif]-->

</head>
<body class="skin-black">
<!-- header logo: style can be found in header.less -->


<div class="wrapper row-offcanvas row-offcanvas-left">
<!-- Left side column. contains the logo and sidebar -->

<?php include('nav_left.php');?>

<!-- /.sidebar -->

<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">
<!-- Content Header (Page header) -->


<!-- Main content -->
<section class="content">

<!-- Small boxes (Stat box) -->
<div class="row" style="/*border: 1px solid #000000; border-radius: 10px;*/">

    <h1 style="text-align: center"><i class="fa fa-calendar"></i> Valve Test Details Reports</h1>
</div>
<!-- /.row -->

<!-- top row -->
<div class="row">
    <div class="col-xs-12 connectedSortable">
        <div class="col-lg-12 connectedSortable" style="padding: 20px;">


            <form action="#" method="post">
                <div style="">
                    <?php

                    $_SESSION['test_no']=$test_no;
                    $_SESSION['test_type']=$test_type;

                    $sql = "SELECT DISTINCT(vd.`valve_serial_no`),vd.`valve_tag_no`,vd.`imir_no`,vd.`manufacturer`,vd.`customer`,vd.`operator`,vd.`shift`,vd.`project`,tr.`gauge_serial_no`,tr.`guage_calibration_date`,tr.`valve_type`,vd.`date_time`,tr.`valve_size`,tr.`valve_class` FROM `test_result` tr  JOIN `valve_data` vd ON (tr.`test_no` = vd.`test_no` AND tr.`test_type` = vd.`test_type`) WHERE  tr.`test_no` = '$test_no'";

                    $result = $conn->query($sql);
                    if ($result->num_rows > 0){
                    if($row = $result->fetch_assoc()){
                    ?>
                    <center>
                        <div class="" style="text-align: center; margin-left: 25%">
                            <table >
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 200px;"><b> VALVE SERIAL NO. </b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['valve_serial_no'];?></td>
                                    <td style="border: 1px solid #000; width: 200px;"><b>CUSTOMER</b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['customer']; ?>  </td>
                                </tr>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 200px;"><b> VALVE TAG NO. </b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['valve_tag_no'];?></td>
                                    <td style="border: 1px solid #000; width: 200px;"><b>OPERATOR NAME </b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['operator'];?></td>
                                </tr>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 200px;"><b>IMIR NO</b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['imir_no'];?></td>
                                    <td style="border: 1px solid #000; width: 200px;"><b>SHIFT</b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['shift'];?></td>
                                </tr>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000;width: 200px;"><b>VALVE SIZE</b> </td>
                                    <td style="border: 1px solid #000;width: 200px;"><?php echo $row['valve_size'];?></td>
                                    <td style="border: 1px solid #000; width: 200px;"><b>  MANUFACTURER </b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['manufacturer'];?></td>
                                </tr>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000;width: 200px;"><b>VALVE CLASS</b> </td>
                                    <td style="border: 1px solid #000;width: 200px;"><?php echo $row['valve_class'];?></td>
                                    <td style="border: 1px solid #000;width: 200px;"><b>TEST DATE</b> </td>
                                    <td style="border: 1px solid #000;width: 200px;"><?php echo $row['date_time'];?></td>
                                </tr>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style="border: 1px solid #000; width: 200px;"><b>VALVE TYPE</b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['valve_type'];}}?></td>
                                    <td style="border: 1px solid #000; width: 200px;"><b>PROJECT</b> </td>
                                    <td style="border: 1px solid #000; width: 200px;"><?php echo $row['project'];?></td>
                                </tr>
                                <tr style="padding: 10px; font-size: 20px; text-align: center">
                                    <td style=" border: 1px solid #000; width: 200px; background: #9e9e9e; color: #000;cursor: pointer" onclick="myFunction()"><b>Export EXCEL</b></td>
                                    <!--                                    <td style=" border: 1px solid #000; width: 200px; background: #9e9e9e; color: #000;cursor: pointer"><b><a href="test.php" style="color: #000" >Export EXCEL</a></b></td>-->
                                    <td style="border: 1px solid #000; width: 200px; background: #9e9e9e;"><b><a href="export.php" style="color: #000" >Export PDF</a></b></td>
                                </tr>
                            </table>


                        </div>
                    </center>
                </div>
            </form>
        </div>
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->
    <script>
    function myFunction() {
    alert("<?php echo $sql;?>");
    }
    </script>
<!-- Main row -->
<div class="row">
<!-- Left col -->
<section class="col-lg-12 connectedSortable">
<!-- Box (with bar chart) -->
<div class="box box-danger" id="loading-example">
<div class="box-header">
    <label class="text-left box-title" ><?php echo $test_type; ?></label>
    <button class="btn btn-social btn-sm" title="Trend" style="float: right; margin: 5px;" onclick="testAlert()"><img src="img/graph4.gif" width="120px" height="50px"></button>
</div>
    <script>
        function testAlert() {
            alert('testing test no');
        }
    </script>
<!-- /.box-header -->

<div class="box-body no-padding" style="width: 100%">

<table id="example1" class="table table-bordered table-hover">
<thead>
<tr>
    <th style="text-align:center;">Sr No.</th>
    <th style="text-align:center;">Date / Time</th>
        <?php if($test_type == 'DOUBLE BLOCK BLEED TEST'){?>
    <th style="text-align:center;">PRESSURE AT A SIDE</th>
    <th style="text-align:center;">PRESSURE AT B SIDE</th>
    <?php }else{?>
            <th style="text-align:center;">PRESSURE</th>
    <?php }?>
</tr>
</thead>
<tbody>

<?php

            $sql1 = "SELECT * FROM `test_result_by_type` WHERE  `test_no` = '$test_no'";
//            echo "all are all ".$sql;



    $result1 = $conn->query($sql1);


    if ($result1->num_rows > 0) {
    $row = $result1->fetch_assoc();
    $SR_NO = 1;
    do {
    ?>
    <tr class="gradeU" style="color: #000">
        <td align="center" valign="middle">
            <?php echo $SR_NO++; ?>
        </td>
        <td align="center" valign="middle">
            <?php echo $row['date_time']; ?>
        </td>

        <?php if($test_type == 'HYDROSTATIC SHELL' || $test_type == 'HYDROSTATIC SEAT A SIDE' || $test_type == 'PNEUMATIC A SIDE'){?>
            <td align="center" valign="middle"><?php echo $row['hydro_pressure_a_side']; ?></td>
        <?php }elseif ($test_type == 'HYDROSTATIC SEAT B SIDE' || $test_type == 'PNEUMATIC B SIDE'){ ?>
            <td lign="center" valign="middle"><?php echo $row['hydro_pressure_b_side']; ?></td>
        <?php }elseif ($test_type == 'DOUBLE BLOCK BLEED TEST'){ ?>
            <td align="center" valign="middle"><?php echo $row['hydro_pressure_a_side']; ?></td>
            <td align="center" valign="middle"><?php echo $row['hydro_pressure_b_side']; ?></td>
        <?php }?>

    </tr>
<?php
} while ($row = $result1->fetch_assoc());
}
else {
echo "invalid date - Not allowed";
?>
    <script>
        alert("invalid date");
    </script>
<?php
}



?>

</tbody>

</table>

</div>
<!-- /.box-body -->
<!-- /.box-body -->
</div>
<!-- /.box -->

<!-- Custom tabs (Charts with tabs)-->


</section>
<!-- /.Left col -->

</div>
<!-- /.row (main row) -->


</section>
<!-- /.content -->
</aside>
<!-- /.right-side -->
</div>
<!-- ./wrapper -->

<!-- add new calendar event modal -->


<!-- jQuery 2.0.2 -->
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>-->
<!-- jQuery UI 1.10.3 -->
<!--<script src="js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>-->
<!-- Bootstrap -->
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- Morris.js charts -->
<!--<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>-->
<!--<script src="js/plugins/morris/morris.min.js" type="text/javascript"></script>-->
<!-- Sparkline -->
<!--<script src="js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>-->
<!-- jvectormap -->
<!--<script src="js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>-->
<!--<script src="js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>-->
<!-- fullCalendar -->
<!--<script src="js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>-->
<!-- jQuery Knob Chart -->
<!--<script src="js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>-->
<!-- daterangepicker -->
<!--<script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>-->
<!-- Bootstrap WYSIHTML5 -->
<!--<script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>-->
<!-- iCheck -->
<!--<script src="js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>-->
<!-- AdminLTE App -->
<script src="js/AdminLTE/app.js" type="text/javascript"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="js/AdminLTE/dashboard.js" type="text/javascript"></script>
<!-- jQuery 2.0.2 -->
<script src="js/jquery.min.js"></script>
<!-- DATA TABES SCRIPT -->
<script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
<!-- AdminLTE App -->

<!-- page script -->
<script type="text/javascript">
    $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
        });
    });
</script>




</body>
</html>
