<?php
session_start();

$conn = new mysqli('localhost', $_SESSION['db_user'], $_SESSION['db_pass'], $_SESSION['db_name']) or trigger_error(mysqli_error(),E_USER_ERROR);


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="img/author.png">
    <title> Reports</title>


    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- bootstrap 3.0.2 -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- font Awesome -->
<!--    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />-->
    <!-- Ionicons -->
<!--    <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />-->
    <!-- DATA TABLES -->
    <link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
<!--    <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />-->
    <!-- Morris chart -->
<!--    <link href="css/morris/morris.css" rel="stylesheet" type="text/css" />-->
    <!-- jvectormap -->
<!--    <link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />-->
    <!-- fullCalendar -->
<!--    <link href="css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />-->
    <!-- Daterange picker -->
<!--    <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />-->
    <!-- bootstrap wysihtml5 - text editor -->
<!--    <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />-->
    <!-- Theme style -->

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <!--<script src="js/html5shiv.js"></script>-->
    <!--<script src="js/respond.min.js"></script>-->
    <![endif]-->





</head>
<body class="skin-black">
<!-- header logo: style can be found in header.less -->

<div class="wrapper row-offcanvas row-offcanvas-left" >
    <!-- Left side column. contains the logo and sidebar -->

    <?php include('nav_left.php');?>

    <!-- /.sidebar -->

    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">

<!--Report1 Start-->

<div>


    <!-- Content Header (Page header) -->
    <section class="content">
       <!-- Small boxes (Stat box) -->
            <div class="row" style="/*border: 1px solid #000000; border-radius: 10px;*/">

                <h1 style="text-align: center"><i class="fa fa-calendar"></i> Weekly Report</h1>
            </div><!-- /.row -->


    <!-- Main row -->
    <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
            <!-- Box (with bar chart) -->
            <div class="box box-danger" id="loading-example">
                <br>
                <div class="box-body no-padding" style="width: 100%">
                        <table id="example1" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="text-align:center;">Sr No.</th>
                                <th style="text-align:center;">Date / Time</th>
                                <th style="text-align:center;">Test Nos</th>
                                <th style="text-align:center;">Customer</th>
                                <th style="text-align:center;">Valve Serial Number</th>
                                <th style="text-align:center;">Valve Type</th>
                                <th style="text-align:center;">Size</th>
                                <th style="text-align:center;">Test Type</th>
                                <th style="text-align:center;">Test Pressure</th>
                                <th style="text-align:center;">Test Result</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php

                            $currentWeekNumber = date('W');
//                            echo 'Week number:' . $currentWeekNumber;

                            $datenow = date('Y-m-d');

                            $first_day_this_month = date('Y-m-01');
                            $datelast = new DateTime($datenow);
                            $signupweek= $datenow;
                            /*start day*/
                            for($i = 0; $i <7 ; $i++)
                            {
                                $weekstart = date('Y-m-d', strtotime("-".$i."days", strtotime($signupweek)));
                                $dayName = date('D', strtotime($weekstart));
                                if($dayName == "Sun")
                                {
                                    $one= $weekstart;
//                                    echo "start day is ". $one."<br>";
                                }
                            }
                            /*end day*/
                            for($i = 0; $i <7 ; $i++)
                            {
                                $weekend = date('Y-m-d', strtotime("+".$i."days", strtotime($signupweek)));
                                $dayName = date('D', strtotime($weekend));
                                if($dayName == "Sat")
                                {
                                   $two= $weekend;
//                                    echo "end day is ". $two."<br>";
                                }
                            }


                            $sql ="SELECT ti.`date_time`,ti.`test_no`,vd.`customer`,vd.`valve_serial_no`,ti.`valve_type`, ti.`valve_size`,ti.`test_type`,ti.`hydro_set_pressure`,tr.`test_result` FROM `test_init` ti JOIN `valve_data` vd ON (ti.`test_no` = vd.`test_no` AND ti.`test_type` = vd.`test_type`) JOIN `test_result` tr ON (tr.`test_no` = ti.`test_no` AND ti.`test_type` = tr.`test_type`) WHERE ti.`date_time` BETWEEN '$one' AND '$two'";


//                            echo $sql;


//                            $date = date('Y-m-d');
//                            echo "The current server timezone is: " . $date;

//                            $sql = "SELECT ti.`date_time`,ti.`test_no`,vd.`customer`,vd.`valve_serial_no`,ti.`valve_type`, ti.`valve_size`,ti.`test_type`,ti.`hydro_set_pressure`,tr.`test_result` FROM `test_init` ti JOIN `valve_data` vd ON (ti.`test_no` = vd.`test_no` AND ti.`test_type` = vd.`test_type`) JOIN `test_result` tr ON (tr.`test_no` = ti.`test_no` AND ti.`test_type` = tr.`test_type`) WHERE WEEK('$date')";

//                              $sql = "SELECT ti.`date_time`,ti.`test_no`,vd.`customer`,vd.`valve_serial_no`,ti.`valve_type`, ti.`valve_size`,ti.`test_type`,ti.`hydro_set_pressure`,tr.`test_result` FROM `test_init` ti JOIN `valve_data` vd ON (ti.`test_no` = vd.`test_no` AND ti.`test_type` = vd.`test_type`) JOIN `test_result` tr ON (tr.`test_no` = ti.`test_no` AND ti.`test_type` = tr.`test_type`)";
//

                            $qresult = $conn->query($sql);

                            if ($qresult->num_rows > 0) {
                                // output data of each row


                                $row = $qresult->fetch_assoc();
                                $SR_NO=1;
                                do { ?>
                                    <tr class="gradeU">
                                        <td align="center" valign="middle">
                                            <?php echo $SR_NO++; ?>
                                        </td>
                                        <td align="center" valign="middle">
                                            <?php echo $row['date_time']; ?>
                                        </td>
                                        <?php if ($row['test_type'] == "CAVITY RELIEF TEST") { ?>
                                            <td align="center" valign="middle">
                                                <a href="#" style="color: #000; font-size: 20px; ">
                                                    <b class=""><?php echo $row['test_no']; ?></b>
                                                </a>
                                            </td>
                                        <?php } else { ?>
                                            <td align="center" valign="middle">
                                                <a href="details_report.php?test_no=<?php echo $row['test_no']; ?>&test_type=<?php echo $row['test_type']; ?>"
                                                   style="color: #000; font-size: 20px; ">
                                                    <b class="details"><?php echo $row['test_no']; ?></b>
                                                </a>
                                            </td>
                                        <?php } ?>
                                        <td align="center" valign="middle">
                                            <?php echo $row['customer']; ?>
                                        </td>
                                        <td align="center" valign="middle">
                                            <a href="new_vtr_reports.php?valve_serial_no=<?php echo $row['valve_serial_no'];?>" style="color: #000; font-size: 20px; ">
                                                <b class="vtr"><?php echo $row['valve_serial_no']; ?></b>
                                            </a>
                                        </td>
                                        <td align="center" valign="middle">
                                            <?php echo $row['valve_type']; ?>
                                        </td>
                                        <td align="center" valign="middle">
                                            <?php echo $row['valve_size']; ?>
                                        </td>
                                        <td align="center" valign="middle">
                                            <?php echo $row['test_type']; ?>
                                        </td>
                                        <td align="center" valign="middle">
                                            <?php echo $row['hydro_set_pressure']; ?>
                                        </td>
                                        <td align="center" valign="middle">
                                            <?php if($row['test_result']==1){
                                                echo "TEST OK";
                                            }else{
                                                echo  "TEST NOT OK";
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php } while ($row =  $qresult->fetch_assoc());

                            }
                            else {
//                                echo "0 results";
                            }
                        ?>

                        </tbody>

                    </table>


                </div><!-- /.box-body -->
            </div><!-- /.box -->

            <!-- Custom tabs (Charts with tabs)-->



        </section><!-- /.Left col -->
        <!-- right col (We are only adding the ID to make the widgets sortable)-->
        <!-- right col -->
    </div><!-- /.row (main row) -->

<!-- add new calendar event modal -->


    </section>
</div>




    </aside><!-- /.right-side -->
</div><!-- ./wrapper -->

<!--Report1 END-->

<!-- /.modal End-->


<!-- jQuery 2.0.2 -->
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>-->
<!-- jQuery UI 1.10.3 -->
<!--<script src="js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>-->
<!-- Bootstrap -->
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<!-- Morris.js charts -->
<!--<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>-->
<!--<script src="js/plugins/morris/morris.min.js" type="text/javascript"></script>-->
<!-- Sparkline -->
<!--<script src="js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>-->
<!-- jvectormap -->
<!--<script src="js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>-->
<!--<script src="js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>-->
<!-- fullCalendar -->
<!--<script src="js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>-->
<!-- jQuery Knob Chart -->
<!--<script src="js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>-->
<!-- daterangepicker -->
<!--<script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>-->
<!-- Bootstrap WYSIHTML5 -->
<!--<script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>-->
<!-- iCheck -->
<!--<script src="js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>-->
<!-- AdminLTE App -->
<script src="js/AdminLTE/app.js" type="text/javascript"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="js/AdminLTE/dashboard.js" type="text/javascript"></script>
<!-- jQuery 2.0.2 -->
<script src="js/jquery.min.js"></script>
<!-- DATA TABES SCRIPT -->
<script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
<!-- AdminLTE App -->

<!-- page script -->
<script type="text/javascript">
    $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
        });
    });
</script>
</body>
</html>
