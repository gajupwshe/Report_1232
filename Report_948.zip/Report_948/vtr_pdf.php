<?php
//export.php


session_start();

$SR_NO = 1;
$output = '';


require_once('tcpdf/tcpdf.php');

$obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$obj_pdf->SetCreator(PDF_CREATOR);
$obj_pdf->SetTitle("Creintors-Hydrothrust");

$obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$obj_pdf->setFooterData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE . '  ', PDF_HEADER_STRING, array(0, 64, 0), array(0, 64, 128));
$obj_pdf->SetDefaultMonospacedFont('helvetica');
$obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$obj_pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);
$obj_pdf->setPrintHeader(true);
$obj_pdf->setPrintFooter(true);
$obj_pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
$obj_pdf->SetFont('helvetica', '', 11);
$obj_pdf->AddPage();
$content = '';
$content .= '
<img  src="img/L&T_logo.png" style="height: 50px;" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; VALVE TEST REPORTS<br/>';
$conn1 = new mysqli('localhost', $_SESSION['db_user'], $_SESSION['db_pass'], $_SESSION['db_name']) or trigger_error(mysqli_error(), E_USER_ERROR);
$valve_serial_no = $_SESSION['valve_serial_no'];
$sql = "SELECT DISTINCT(vd.`valve_serial_no`),vd.`valve_tag_no`,vd.`imir_no`,vd.`manufacturer`,vd.`customer`,vd.`operator`,vd.`shift`,vd.`project`,tr.`gauge_serial_no`,tr.`guage_calibration_date`,tr.`valve_type`,vd.`date_time`,tr.`valve_size`,tr.`valve_class` FROM `test_result` tr  JOIN `valve_data` vd ON (tr.`test_no` = vd.`test_no` AND tr.`test_type` = vd.`test_type`) WHERE  tr.`valve_serial_no` = '$valve_serial_no'";
//echo $sql."<br/> new ";
$valve_serial = '';
$valve_tag = '';
$imir_no = '';
$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
	$valve_serial = $row['valve_serial_no'];
	$valve_tag = $row['valve_tag_no'];
	$imir_no = $row['imir_no'];
        $content .= ' 
             <table border="" >
                  <tr style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; VALVE SERIAL NO. </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['valve_serial_no'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; CUSTOMER </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['customer'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; VALVE TAG NO. </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['valve_tag_no'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; MANUFACTURER </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['manufacturer'] . ' </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; IMIR NO.</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row["imir_no"] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PROJECT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['project'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; VALVE TYPE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['valve_type'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; VALVE CLASS </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['valve_class'] . ' </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; VALVE SIZE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['valve_size'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"></td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"></td>
                 </tr>
		<tr style="padding: 8px; font-size: 3px; text-align: center">
                        <td style="border: 1px solid #000; width: 520px;text-align: start;"> </td>
                 </tr>
                 </table>
                 
          ';
    }
}


$shell_test_no = '45';
$sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='HYDROSTATIC SHELL'  ORDER BY `test_no` DESC LIMIT 1";

$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $shell_test_no = $row['test_no'];
    }
}
$sql_shell = "SELECT tr.*,vr.*, gd.`c_date`,gd.`c_due_date` FROM `test_result` tr JOIN gauge_data gd ON (tr.gauge_serial_no = gd.serial) JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$shell_test_no'";
$result_shell = $conn1->query($sql_shell);
if ($result_shell->num_rows > 0) {
    if ($row = $result_shell->fetch_assoc()) {
        $content .= '<table>
             <tr  style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; TEST TYPE: </td>
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; HYDROSTATIC SHELL </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE GAUGE NO.  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['gauge_serial_no'] . ' </td>
</tr>
 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DONE DATE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_date'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DUE DATE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_due_date'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; TEST DATE  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['date_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; WATER TEMPERATURE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['water_temperature'] . '&deg;C  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp;  OPERATOR NAME  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['operator'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SHIFT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['shift'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SET PRESSURE (' . $row['pressure_unit'] . ') </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['hydro_set_pressure'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START (' . $row['pressure_unit'] . ') </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . ' </td>
                 </tr>
                  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END (' . $row['pressure_unit'] . ')  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_a'] . '  </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; HOLDING TIME ACTUAL (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['holding_time'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OVERALL TEST TIME (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['over_all_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; RESULT </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ';
        if ($row['test_result'] == '0') {
            $content .= '  TEST NOT OK';
        } else {
            $content .= '  TEST OK';
        }
        $content .= '</td>
                 </tr>
                 </table>
';
    }
} else {

}


$sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='HYDROSTATIC SEAT A SIDE'  ORDER BY `test_no` DESC LIMIT 1";
$seat_a_test_no = '45';
$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $seat_a_test_no = $row['test_no'];
    }
}
$sql_seat_a = "SELECT tr.*,vr.*, gd.`c_date`,gd.`c_due_date` FROM `test_result` tr JOIN gauge_data gd ON (tr.gauge_serial_no = gd.serial) JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` =  '$seat_a_test_no'";
$result_seat_a = $conn1->query($sql_seat_a);
if ($result_seat_a->num_rows > 0) {
    if ($row = $result_seat_a->fetch_assoc()) {
        $content .= '<table>
             <tr  style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; TEST TYPE:</td>
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; HYDROSTATIC SEAT A SIDE </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE GAUGE NO.  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['gauge_serial_no'] . ' </td>

</tr>
 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DONE DATE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_date'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DUE DATE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_due_date'] . '  </td>
                 </tr>';
        if($row['leakage_type'] == "NONE"){
        }else{
		$ltlt = $row['leakage_type'];
		$get_leakage_unit = "SELECT `unit` FROM  `actual_leakage` WHERE `leakage_type` = '$ltlt';";
		//echo $get_leakage_unit;
		$result_unit = $conn1->query($get_leakage_unit);
		if ($result_unit->num_rows > 0) {
    			if ($row_unit = $result_unit->fetch_assoc()) {
            $content .= '  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; LEAKAGE TYPE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;">&nbsp; '. $row['leakage_type'].' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; ACTUAL LEAKAGE ('.$row_unit['unit'].')</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;">&nbsp; '.$row['actual_leakage'].'  </td>
                 </tr>';
			}
		}
        }
        $content .= '  
             <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; TEST DATE  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['date_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; WATER TEMPERATURE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['water_temperature'] . '&deg;C  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OPERATOR NAME  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['operator'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SHIFT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['shift'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SET PRESSURE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['hydro_set_pressure'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . ' </td>
                 </tr>
                  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END ' . $row['pressure_unit'] . '  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_a'] . '  </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; HOLDING TIME ACTUAL (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['holding_time'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OVERALL TEST TIME (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['over_all_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; RESULT </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ';
        if ($row['test_result'] == '0') {
            $content .= '  TEST NOT OK';
        } else {
            $content .= '  TEST OK';
        }
        $content .= '</td>
                 </tr>
                 </table>
';
    }
} else {

}


$sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='HYDROSTATIC SEAT B SIDE'  ORDER BY `test_no` DESC LIMIT 1";
$seat_b_test_no = '45';
$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $seat_b_test_no = $row['test_no'];
    }
}

$sql_seat_b = "SELECT tr.*,vr.*, gd.`c_date`,gd.`c_due_date` FROM `test_result` tr JOIN gauge_data gd ON (tr.gauge_serial_no = gd.serial) JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` =  '$seat_b_test_no'";
$result_seat_b = $conn1->query($sql_seat_b);
if ($result_seat_b->num_rows > 0) {
    if ($row = $result_seat_b->fetch_assoc()) {
        $content .= '<table>
             <tr  style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; TEST TYPE: </td>
             <td style="border: 1px solid #000; width: 130PX;text-align: start;"> &nbsp; HYDROSTATIC SEAT B SIDE </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE GAUGE NO.  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['gauge_serial_no'] . ' </td>
</tr>
 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DONE DATE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_date'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DUE DATE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_due_date'] . '  </td>
                 </tr>';
        if($row['leakage_type'] == "NONE"){
        }else{
		$ltlt = $row['leakage_type'];
		$get_leakage_unit = "SELECT `unit` FROM  `actual_leakage` WHERE `leakage_type` = '$ltlt';";
		//echo $get_leakage_unit;
		$result_unit = $conn1->query($get_leakage_unit);
		if ($result_unit->num_rows > 0) {
    			if ($row_unit = $result_unit->fetch_assoc()) {
            $content .='  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b>&nbsp; LEAKAGE TYPE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;">&nbsp; '. $row['leakage_type'].' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b>&nbsp; ACTUAL LEAKAGE ('.$row_unit['unit'].')</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;">&nbsp; '.$row['actual_leakage'].'  </td>
                 </tr>';
			}
		}
        }
        $content .= '  
             <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; TEST DATE  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['date_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; WATER TEMPERATURE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['water_temperature'] . '&deg;C  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OPERATOR NAME  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['operator'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SHIFT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['shift'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SET PRESSURE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['hydro_set_pressure'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . ' </td>
                 </tr>
                  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END ' . $row['pressure_unit'] . '  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_a'] . '  </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; HOLDING TIME ACTUAL (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['holding_time'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OVERALL TEST TIME (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['over_all_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; RESULT </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ';
        if ($row['test_result'] == '0') {
            $content .= '  TEST NOT OK';
        } else {
            $content .= '  TEST OK';
        }
        $content .= '</td>
                 </tr>
                 </table>
';
    }
} else {

}


$sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='PNEUMATIC SEAT A SIDE'  ORDER BY `test_no` DESC LIMIT 1";
$air_a_test_no = '45';
$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $air_a_test_no = $row['test_no'];
    }
}
$sql_air_a = "SELECT tr.*,vr.*, gd.`c_date`,gd.`c_due_date` FROM `test_result` tr JOIN gauge_data gd ON (tr.gauge_serial_no = gd.serial) JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` =   '$air_a_test_no'";
$result_air_a = $conn1->query($sql_air_a);
if ($result_air_a->num_rows > 0) {
    if ($row = $result_air_a->fetch_assoc()) {
        $content .= '<table>
             <tr  style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; TEST TYPE: </td>
             <td style="border: 1px solid #000; width: 130PX;text-align: start;"> &nbsp; PNEUMATIC SEAT A SIDE</td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE GAUGE NO.  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['gauge_serial_no'] . ' </td>
</tr>
 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DONE DATE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_date'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DUE DATE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_due_date'] . '  </td>
                 </tr>';
        if($row['leakage_type'] == "NONE"){
        }else{
		$ltlt = $row['leakage_type'];
		$get_leakage_unit = "SELECT `unit` FROM  `actual_leakage` WHERE `leakage_type` = '$ltlt';";
		//echo $get_leakage_unit;
		$result_unit = $conn1->query($get_leakage_unit);
		if ($result_unit->num_rows > 0) {
    			if ($row_unit = $result_unit->fetch_assoc()) {
            $content .= '  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b>&nbsp; LEAKAGE TYPE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;">&nbsp; '. $row['leakage_type'].' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b>&nbsp; BUBBLE COUNT ('.$row_unit['unit'].')</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;">&nbsp; '.$row['actual_leakage'].'  </td>
                 </tr>';
			}
		}
        }
        $content .= '  
             <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; TEST DATE  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['date_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; WATER TEMPERATURE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['water_temperature'] . '&deg;C  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OPERATOR NAME  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['operator'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SHIFT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['shift'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SET PRESSURE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['hydro_set_pressure'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . ' </td>
                 </tr>
                  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END ' . $row['pressure_unit'] . '  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_a'] . '  </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; HOLDING TIME ACTUAL (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['holding_time'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OVERALL TEST TIME (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['over_all_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; RESULT </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ';
        if ($row['test_result'] == '0') {
            $content .= '  TEST NOT OK';
        } else {
            $content .= '  TEST OK';
        }
        $content .= '</td>
                 </tr>
                 </table>
';
    }
} else {

}


$sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='PNEUMATIC SEAT B SIDE'  ORDER BY `test_no` DESC LIMIT 1";
$air_b_test_no = '45';
$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $air_b_test_no = $row['test_no'];
    }
}
$sql_air_b = "SELECT tr.*,vr.*, gd.`c_date`,gd.`c_due_date` FROM `test_result` tr JOIN gauge_data gd ON (tr.gauge_serial_no = gd.serial) JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$air_b_test_no'";
$result_air_b = $conn1->query($sql_air_b);
if ($result_air_b->num_rows > 0) {
    if ($row = $result_air_b->fetch_assoc()) {
        $content .= '<table>
             <tr  style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; TEST TYPE: </td>
             <td style="border: 1px solid #000; width: 130PX;text-align: start;"> &nbsp; PNEUMATIC SEAT B SIDE</td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE GAUGE NO.  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['gauge_serial_no'] . ' </td>
</tr>
 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DONE DATE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_date'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DUE DATE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_due_date'] . '  </td>
                 </tr>';
        if($row['leakage_type'] == "NONE"){
        }else{
		$ltlt = $row['leakage_type'];
		$get_leakage_unit = "SELECT `unit` FROM  `actual_leakage` WHERE `leakage_type` = '$ltlt';";
		//echo $get_leakage_unit;
		$result_unit = $conn1->query($get_leakage_unit);
		if ($result_unit->num_rows > 0) {
    			if ($row_unit = $result_unit->fetch_assoc()) {
            $content .= '  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b>&nbsp; LEAKAGE TYPE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;">&nbsp; '. $row['leakage_type'].' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b>&nbsp; BUBBLE COUNT ('.$row_unit['unit'].')</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;">&nbsp; '.$row['actual_leakage'].'  </td>
                 </tr>';
			}
		}
        }
        $content .= '  
             <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; TEST DATE  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['date_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; WATER TEMPERATURE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['water_temperature'] . '&deg;C  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OPERATOR NAME  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['operator'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SHIFT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['shift'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SET PRESSURE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['hydro_set_pressure'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . ' </td>
                 </tr>
                  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END ' . $row['pressure_unit'] . '  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_a'] . '  </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; HOLDING TIME ACTUAL (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['holding_time'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OVERALL TEST TIME (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['over_all_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; RESULT </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ';
        if ($row['test_result'] == '0') {
            $content .= '  TEST NOT OK';
        } else {
            $content .= '  TEST OK';
        }
        $content .= '</td>
                 </tr>
                 </table>
';
    }
} else {

}


$sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='DOUBLE BLOCK BLEED TEST'  ORDER BY `test_no` DESC LIMIT 1";
$double_test_no = '45';
$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $double_test_no = $row['test_no'];
    }
}

$sql_double = "SELECT tr.*,vr.*, gd.`c_date`,gd.`c_due_date` FROM `test_result` tr JOIN gauge_data gd ON (tr.gauge_serial_no = gd.serial) JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$double_test_no'";
$result_double = $conn1->query($sql_double);
if ($result_double->num_rows > 0) {
    if ($row = $result_double->fetch_assoc()) {
        $content .= '<table>
             <tr  style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; TEST TYPE:</td>
             <td style="border: 1px solid #000; width: 130PX;text-align: start;"> &nbsp; DOUBLE BLOCK BLEED TEST</td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE GAUGE NO.  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['gauge_serial_no'] . ' </td>
</tr>
 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DONE DATE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_date'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DUE DATE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_due_date'] . '  </td>
                 </tr>
             <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; TEST DATE  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['date_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; WATER TEMPERATURE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['water_temperature'] . '&deg;C  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OPERATOR NAME  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['operator'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SHIFT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['shift'] . '  </td>
                 </tr>                
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START A SIDE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END A SIDE ' . $row['pressure_unit'] . '  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_a'] . '  </td>
                 </tr>
                  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START B SIDE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_b'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END B SIDE' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_b'] . '  </td>
                 </tr>                 
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SET PRESSURE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['hydro_set_pressure'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . ' </td>
                 </tr>
                  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END ' . $row['pressure_unit'] . '  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_a'] . '  </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; HOLDING TIME ACTUAL (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['holding_time'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OVERALL TEST TIME (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['over_all_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; RESULT </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ';
        if ($row['test_result'] == '0') {
            $content .= '  TEST NOT OK';
        } else {
            $content .= '  TEST OK';
        }
        $content .= '</td>
                 </tr>
                 </table>
';
    }
} else {

}


$sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='BACK SEAT TEST'  ORDER BY `test_no` DESC LIMIT 1";
$back_seat_test_no = '45';
$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $back_seat_test_no = $row['test_no'];
    }
}

$sql_back_seat = "SELECT tr.*,vr.*, gd.`c_date`,gd.`c_due_date` FROM `test_result` tr JOIN gauge_data gd ON (tr.gauge_serial_no = gd.serial) JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$back_seat_test_no'";
$result_back_seat = $conn1->query($sql_back_seat);
if ($result_back_seat->num_rows > 0) {
    if ($row = $result_back_seat->fetch_assoc()) {
        $content .= '<table>
             <tr  style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; TEST TYPE: </td>
             <td style="border: 1px solid #000; width: 130PX;text-align: start;"> &nbsp; BACK SEAT TEST</td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE GAUGE NO.  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['gauge_serial_no'] . ' </td>
</tr>
 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DONE DATE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_date'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DUE DATE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_due_date'] . '  </td>
                 </tr>
             <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; TEST DATE  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['date_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; WATER TEMPERATURE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['water_temperature'] . '&deg;C  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OPERATOR NAME  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['operator'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SHIFT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['shift'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SET PRESSURE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['hydro_set_pressure'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT START ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . ' </td>
                 </tr>
                  <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE AT END ' . $row['pressure_unit'] . '  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['stop_pressure_a'] . '  </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; HOLDING TIME ACTUAL (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['holding_time'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OVERALL TEST TIME (SEC)</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['over_all_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; RESULT </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ';
        if ($row['test_result'] == '0') {
            $content .= '  TEST NOT OK';
        } else {
            $content .= '  TEST OK';
        }
        $content .= '</td>
                 </tr>
                 </table>
';
    }
} else {

}


$sql = "SELECT `test_no` FROM `test_result` WHERE  `valve_serial_no` = '$valve_serial_no' AND `test_type` ='CAVITY RELIEF TEST'  ORDER BY `test_no` DESC LIMIT 1";
$cavity_relief_test = '45';
$result = $conn1->query($sql);
if ($result->num_rows > 0) {
    if ($row = $result->fetch_assoc()) {
        $cavity_relief_test = $row['test_no'];
    }
}
$sql_cavity_relief = "SELECT tr.*,vr.*, gd.`c_date`,gd.`c_due_date` FROM `test_result` tr JOIN gauge_data gd ON (tr.gauge_serial_no = gd.serial) JOIN `valve_data` vr ON (tr.`test_no` = vr.`test_no`) WHERE tr.`test_no` = '$cavity_relief_test'";
$result_cavity_relief_test = $conn1->query($sql_cavity_relief);
if ($result_cavity_relief_test->num_rows > 0) {
    if ($row = $result_cavity_relief_test->fetch_assoc()) {
        $content .= ' <table>
 
             <tr style="padding: 8px; font-size: 7px; text-align: center; border: 1px solid #000;">
             <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; TEST TYPE:</td>
             <td style="border: 1px solid #000; width: 130PX;text-align: start;"> &nbsp; CAVITY RELIEF TEST</td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; PRESSURE GAUGE NO.  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['gauge_serial_no'] . ' </td>
</tr>
 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DONE DATE </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_date'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; GAUGE CALIBRATION DUE DATE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['c_due_date'] . '  </td>
                 </tr>
             <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; TEST DATE  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['date_time'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; WATER TEMPERATURE</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['water_temperature'] . '&deg;C  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; OPERATOR NAME  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['operator'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; SHIFT</b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['shift'] . '  </td>
                 </tr>
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; CAVITY RELIEF PRESSURE ' . $row['pressure_unit'] . ' </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['hydro_set_pressure'] . ' </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; ACTUAL CAVITY RELIEF PRESSURE  ' . $row['pressure_unit'] . '  </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ' . $row['start_pressure_a'] . '  </td>
                 </tr>
                 
                 <tr style="padding: 8px; font-size: 7px; text-align: center">
                 
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"><b> &nbsp; RESULT </b> </td>
                        <td style="border: 1px solid #000; width: 130px;text-align: start;"> &nbsp; ';
        if ($row['test_result'] == '0') {
            $content .= '  TEST NOT OK';
        } else {
            $content .= '  TEST OK';
        }
        $content .= '</td>
                 </tr>
            </table>
';
    }
} else {

}


$content .= '
<table align="center">
<br/><br/>
<tr>
<td style="border: 1px solid #000; width: 130px;"></td>
<td style="border: 1px solid #000; width: 130px;text-align: start;">SUBCONTRACTOR</td>
<td style="border: 1px solid #000; width: 130px;text-align: start;">CONTRACTOR</td>
<td style="border: 1px solid #000; width: 130px;text-align: start;">COMPANY</td>
</tr>
<tr style="height: 130px;">
<td style="border: 1px solid #000; width: 130px; "> NAME</td>
<td style="border: 1px solid #000; width: 130px;"></td>
<td style="border: 1px solid #000; width: 130px;"></td>
<td style="border: 1px solid #000; width: 130px;"></td>
</tr>
<tr style="height: 130px;">
<td style="border: 1px solid #000; width: 130px; "> SIGN. </td>
<td style="border: 1px solid #000; width: 130px;"></td>
<td style="border: 1px solid #000; width: 130px;"></td>
<td style="border: 1px solid #000; width: 130px;"></td>
</tr>
<tr style="height: 130px;">
<td style="border: 1px solid #000; width: 130px; "> DATE</td>
<td style="border: 1px solid #000; width: 130px;"></td>
<td style="border: 1px solid #000; width: 130px;"></td>
<td style="border: 1px solid #000; width: 130px;"></td>
</tr>


</table>';


$obj_pdf->writeHTML($content);
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
//echo date('d-m-Y H:i:s');

$date = date("d-m-Y H:i:s");


$path = "Report_948/reports/Valve_Test_Reports/VALVE_TEST_REPORT_of_".$valve_serial."_".$valve_tag."_".$imir_no;
//$path = "Report_948/aka";

$obj_pdf->Output($_SERVER['DOCUMENT_ROOT'] . $path . '.pdf', 'F');


//echo "test no".$_SESSION['test_no'];
//echo "test type".$_SESSION['test_type'];
?>


<script>alert("PDF SAVED SUCCESSFULLY_split_<?php echo $path;?>")</script>

<script>window.location = "new_vtr_reports.php?valve_serial_no=<?php echo $_SESSION['valve_serial_no'];?>"; </script>
